package com.corejava.main;

import com.corejava.model.Car;
import com.corejava.model.Bike;

public class Main {
	
	public static void main(String [] args) {
		Car car1 = new Car(4, 7, "Mahindra XUV 700", "TN 43 L 8540", 500, "SUV");
		Bike bike1 = new Bike(2, 2, "Yamaha MT 15", "TN 43 J 6067", 150);
		
		car1.displayCarDetails();
		car1.start();
		car1.drive();
		car1.stop();
		
		bike1.displayBikeDetails();
		bike1.start();
		bike1.drive();
		bike1.stop();
	}
	
}
