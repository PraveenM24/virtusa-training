package com.corejava.model;

public class Vehicle {
	
	private int noOfTyres;
	private int noOfSeats;
	private String brand;
	private String vehicleNo;
	
	
	public Vehicle(int t, int s, String b, String v) {
		this.noOfTyres = t;
		this.noOfSeats = s;
		this.brand = b;
		this.vehicleNo = v;
	}
	
	public void start() {
		System.out.println("Vehicle Started");
	}
	
	public void drive() {
		System.out.println("Driving Vehicle");
	}
	
	public void stop() {
		System.out.println("Vehicle Stopped");
	}

	public int getNoOfTyres() {
		return noOfTyres;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public String getBrand() {
		return brand;
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

}
