package com.corejava.model;

public class Bike extends Vehicle {
	private int engineCC;

	public Bike(int tyres, int seats, String brand, String vehicleNo, int engineCC) {
		super(tyres, seats, brand, vehicleNo);
		this.engineCC = engineCC;
	}
	
	@Override
	public void start() {
		System.out.println("Bike Started");
	}
	
	@Override
	public void drive() {
		System.out.println("Driving Bike");
	}
	
	@Override
	public void stop() {
		System.out.println("Bike Stopped");
	}
	
	public void displayBikeDetails() {
		System.out.println("Bike Details:");
		System.out.println("Vehicle No: "+super.getVehicleNo()
								+" \nBrand: "+super.getBrand()
								+" \nEngine CC: "+engineCC
								+" \nTyres: "+super.getNoOfTyres()
								+" \nSeats: "+super.getNoOfSeats());
	}

}
