package com.corejava.model;

public class Car extends Vehicle {
	private int bootSpace;
	private String type;
	
	public Car(int tyres, int seats, String brand, String vehicleNo, int bootSpace, String type) {
		super(tyres, seats, brand, vehicleNo);
		this.bootSpace = bootSpace;
		this.type = type;
	}
	
	@Override
	public void start() {
		System.out.println("Car Started");
	}
	
	@Override
	public void drive() {
		System.out.println("Driving Car");
	}
	
	@Override
	public void stop() {
		System.out.println("Car Stopped");
	}
	
	public void displayCarDetails() {
		System.out.println("Car Details:");
		System.out.println("Vehicle No: "+super.getVehicleNo()
								+" \nBrand: "+super.getBrand()
								+" \nBootSpace(in litres): "+bootSpace
								+" \nType: "+type
								+" \nTyres: "+super.getNoOfTyres()
								+" \nSeats: "+super.getNoOfSeats());
	}
}
