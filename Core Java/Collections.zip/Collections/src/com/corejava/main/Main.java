package com.corejava.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		// ArrayList
		List<Integer> arrayList1 = new ArrayList<>();
		Collections.addAll(arrayList1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

		// All Numbers
		arrayList1.stream().forEach(el -> System.out.print(el + "\t"));
		System.out.println();

		// Even Numbers
		arrayList1.stream().forEach(el -> {
			if (el % 2 == 0) {
				System.out.print(el + "\t");
			}
		});
		System.out.println();
		

		// LinkedList
		List<Integer> linkedList1 = new LinkedList<>();
		Collections.addAll(linkedList1, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20);

		// All Numbers
		linkedList1.stream().forEach(el -> System.out.print(el + "\t"));
		System.out.println();

		// Even Numbers
		linkedList1.stream().forEach(el -> {
			if (el % 2 == 0) {
				System.out.print(el + "\t");
			}
		});
		System.out.println();
		

		// HashSet
		Set<Integer> hashSet1 = new HashSet<>();
		Collections.addAll(hashSet1, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30);

		// All Numbers
		hashSet1.stream().forEach(el -> System.out.print(el + "\t"));
		System.out.println();

		// Even Numbers
		hashSet1.stream().forEach(el -> {
			if (el % 2 == 0) {
				System.out.print(el + "\t");
			}
		});
		System.out.println();
		

		// TreeSet
		Set<Integer> treeSet1 = new TreeSet<>();
		Collections.addAll(treeSet1, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40);

		// All Numbers
		treeSet1.stream().forEach(el -> System.out.print(el + "\t"));
		System.out.println();

		// Even Numbers
		treeSet1.stream().forEach(el -> {
			if (el % 2 == 0) {
				System.out.print(el + "\t");
			}
		});
		System.out.println();

	}

}
