package com.corejava.main;

import com.corejava.model.CurrencyConverter;
import com.corejava.model.DistanceConverter;
import com.corejava.model.TimeConverter;
import java.util.Scanner;

public class ConverterMain {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		CurrencyConverter c = new CurrencyConverter();
		DistanceConverter d = new DistanceConverter();
		TimeConverter t = new TimeConverter();
		int choice;
		do
		{
			System.out.println("1. Dollar to Rupee ");
			System.out.println("2. Rupee to Dollar ");
			System.out.println("3. Meter to Kilometer ");
			System.out.println("4. Kilometer to Meter ");
			System.out.println("5. Hours to Minutes");
			System.out.println("6. Minutes to Hours");
			System.out.println("7. Exit");
			System.out.println("Enter ur choice");
			choice=sc.nextInt();
			switch(choice){
				case 1:
					c.dollarToRupee();
					break;
				case 2:
					c.rupeeToDollar();
					break;
				case 3 :
					d.meterTokm();
					break;
				case 4 :
					d.kmTometer();
					break;
				case 5:
					t.hoursToMinutes();
					break;
				case 6 :
					t.minutesToHours();
					break;
				case 7:
					sc.close();
					System.exit(0);
					break;
				default:
					System.out.println("Invalid Option");
			}
		}while(choice != 7);
		
	}
}
