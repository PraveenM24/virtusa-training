package com.corejava.model;

import java.util.Scanner;

public class TimeConverter {
	int hours;
	int minutes;
	int input;
	Scanner sc = new Scanner(System.in);
	public void minutesToHours(){
		System.out.print("Enter the number of minutes: ");
		minutes=sc.nextInt();
		hours=minutes/60;
		minutes=minutes%60;
		System.out.println("Hours: " + hours);
		System.out.println("Minutes: " + minutes);
	}
	public void hoursToMinutes(){ 
		System.out.println("enter the no of hours");
		hours=sc.nextInt();
		minutes=(hours*60);
		System.out.println("Minutes: " + minutes);
	}

}
