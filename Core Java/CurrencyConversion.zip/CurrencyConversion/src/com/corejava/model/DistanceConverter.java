package com.corejava.model;

import java.util.Scanner;

public class DistanceConverter {
	double km;
	double m;
	Scanner sc = new Scanner(System.in);
	public void kmTometer(){
		System.out.print("Enter in km ");
		km=sc.nextDouble();
		m=(km*1000);
		System.out.println(km+" km" +" equal to "+m+" metres");
	}
	public void meterTokm(){
		System.out.print("Enter in meter ");
		m=sc.nextDouble();
		km=(m/1000);
		System.out.println(m+"m" +"equal to"+km+"kilometres");
	}

}
