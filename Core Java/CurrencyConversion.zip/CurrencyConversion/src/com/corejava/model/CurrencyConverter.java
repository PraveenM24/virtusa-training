package com.corejava.model;

import java.util.Scanner;

public class CurrencyConverter {
	double inr;
	double usd;
	Scanner sc=new Scanner(System.in);
	public void dollarToRupee(){
		System.out.println("Enter dollars to convert into rupees:");
		usd=sc.nextInt();
		inr=usd*80;
		System.out.println(usd+" dollars is equal to "+inr+" rupees.");
	}
	public void rupeeToDollar(){
		System.out.println("Enter rupees to convert into dollars:");
		inr=sc.nextInt();
		usd=inr/80;
		System.out.println(inr+" rupees is equal to "+usd+" dollars");
	}

}
