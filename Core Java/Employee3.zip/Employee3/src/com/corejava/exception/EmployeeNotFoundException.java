package com.corejava.exception;

import org.apache.log4j.Logger;

public class EmployeeNotFoundException extends RuntimeException {
	
	public static final Logger log = Logger.getLogger(EmployeeNotFoundException.class);
	
	public EmployeeNotFoundException() {
		log.error("Exception in thread \"" + Thread.currentThread().getName() + "\" ");
		super.printStackTrace();
		System.exit(0);
	}

}
