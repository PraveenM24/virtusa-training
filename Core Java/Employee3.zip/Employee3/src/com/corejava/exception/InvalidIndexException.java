package com.corejava.exception;

import org.apache.log4j.Logger;

public class InvalidIndexException extends RuntimeException{
	
	public static final Logger log = Logger.getLogger(InvalidIndexException.class);

	public InvalidIndexException() {
		log.error("Exception in thread \"" + Thread.currentThread().getName() + "\" ");
		super.printStackTrace();
		System.exit(0);
	}
	
}
