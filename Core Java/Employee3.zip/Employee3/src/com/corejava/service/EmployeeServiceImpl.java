package com.corejava.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.Logger;

import com.corejava.exception.EmployeeNotFoundException;
import com.corejava.exception.InvalidIndexException;
import com.corejava.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	public static final Logger log = Logger.getLogger(EmployeeServiceImpl.class);

	@Override
	public Employee searchEmployee(int id, List<Employee> employees) {
		log.info("Searching Employee");
		for (Employee e : employees) {
			if (e.getId() == id) {
				return e;
			}
		}
		throw new EmployeeNotFoundException();
	}

	@Override
	public List<Employee> searchEmployee(String name, List<Employee> employees) throws EmployeeNotFoundException {
		List<Employee> result = new ArrayList<>();
		log.info("Searching Employee");
		for (Employee e : employees) {
			if (e.getName().equalsIgnoreCase(name)) {
				result.add(e);
			}
		}
		if (result.isEmpty()) {
			throw new EmployeeNotFoundException();
		} else {
			return result;
		}
	}

	@Override
	public boolean updateEmployee(int id, float newSalary, List<Employee> employees) throws EmployeeNotFoundException {
		for (Employee e : employees) {
			if (e.getId() == id) {
				e.setSalary(newSalary);
				return true;
			}
		}
		throw new EmployeeNotFoundException();
	}

	@Override
	public boolean removeEmployee(int id, List<Employee> employees) throws EmployeeNotFoundException {
		for (Employee e : employees) {
			if (e.getId() == id) {
				employees.remove(e);
				return true;
			}
		}
		throw new EmployeeNotFoundException();
	}

	@Override
	public boolean updateEmployee(Employee oldEmp, Employee newEmp, List<Employee> employees)
			throws EmployeeNotFoundException {
		for (Employee e : employees) {
			if (e.getId() == oldEmp.getId()) {
				employees.remove(oldEmp);
				employees.add(newEmp);
				return true;
			}
		}
		throw new EmployeeNotFoundException();

	}

	@Override
	public List<Employee> sortEmployeesBySalary(List<Employee> employees) {
		employees.sort(Comparator.comparing(Employee::getSalary));
		return employees;
	}

	@Override
	public List<Employee> splitEmployees(int start, int end, List<Employee> employees) throws InvalidIndexException {
		return employees.subList(start, end);
	}

	@Override
	public Employee getEmployee(int index, List<Employee> employees) throws InvalidIndexException {
		if (index > employees.size()) {
			throw new InvalidIndexException();
		}
		return employees.get(index);
	}

}
