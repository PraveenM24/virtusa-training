package com.corejava.service;

import java.util.List;

import com.corejava.exception.EmployeeNotFoundException;
import com.corejava.exception.InvalidIndexException;
import com.corejava.model.Employee;

public interface EmployeeService {
	Employee searchEmployee(int id, List<Employee> employees);

	List<Employee> searchEmployee(String name, List<Employee> employees) throws EmployeeNotFoundException;

	boolean updateEmployee(int id, float newSalary, List<Employee> employees) throws EmployeeNotFoundException;

	boolean removeEmployee(int id, List<Employee> employees) throws EmployeeNotFoundException;

	boolean updateEmployee(Employee oldEmp, Employee newEmp, List<Employee> employees) throws EmployeeNotFoundException;

	List<Employee> sortEmployeesBySalary(List<Employee> employees);

	List<Employee> splitEmployees(int start, int end, List<Employee> employees) throws InvalidIndexException;

	Employee getEmployee(int index, List<Employee> employees) throws InvalidIndexException;
}
