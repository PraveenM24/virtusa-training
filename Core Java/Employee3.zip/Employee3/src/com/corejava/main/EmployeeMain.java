package com.corejava.main;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.corejava.model.Employee;
import com.corejava.service.EmployeeServiceImpl;

public class EmployeeMain {

	public static final Logger log = Logger.getLogger(EmployeeMain.class);

	public static void main(String[] args) {
		EmployeeServiceImpl services = new EmployeeServiceImpl();
		List<Employee> employees = new ArrayList<>();

		employees.add(new Employee(1, "Emp1", 8524082460l, 10000.00f));
		employees.add(new Employee(2, "Emp2", 8524082461l, 15000.00f));
		employees.add(new Employee(3, "Emp3", 8524082462l, 18000.00f));
		employees.add(new Employee(4, "Emp4", 8524082463l, 20000.00f));
		employees.add(new Employee(5, "Emp5", 8524082464l, 19000.00f));
		employees.add(new Employee(6, "Emp6", 8524082465l, 25000.00f));

		// A. Search using ID
		services.searchEmployee(2, employees).displayEmployee();

		// B. Search using Name
		services.searchEmployee("Emp6", employees).stream().forEach(Employee::displayEmployee);

		// C. Update Salary
		if (services.updateEmployee(1, 13000.00f, employees)) {
			log.info("Employee Updated");
		}

		// D. Remove Employee using ID
		if (services.removeEmployee(6, employees)) {
			log.info("Employee Removed");
		}

		// E. Replace Employee
		Employee emp7 = new Employee(7, "Emp7", 9530042465l, 21000.00f);
		Employee emp8 = new Employee(8, "Emp8", 8730042465l, 24000.00f);
		employees.add(emp7);
		if (services.updateEmployee(emp7, emp8, employees)) {
			log.info("Employee Updated");
		}

		// G. Sort Employees
		log.info("Sorting Employees...");
		services.sortEmployeesBySalary(employees).stream().forEach(Employee::displayEmployee);

		// H. Split Employees
		log.info("Fetching Sublist of Employees...");
		services.splitEmployees(0, 4, employees).stream().forEach(Employee::displayEmployee);

		// I. Get Employee using Index
		services.getEmployee(3, employees).displayEmployee();

	}

}
