package com.corejava.model;

public class ColorPrinter extends Printer {
	private int blackInkRemaining;
	private int magentaInkRemaining;
	private int cyanInkRemaining;
	private int yellowInkRemaining;
	
	public void print() {
		if(checkInk()) {			
			System.out.println("Printing in Color");
			reduceInk();
		}else {
			System.out.println("No ink left");
		}
	}
	
	public void xerox() {
		if(checkInk()) {			
			System.out.println("Taking Color Xerox");
			reduceInk();
		}else {
			System.out.println("No ink left");
		}
	}
	
	public ColorPrinter(int productNo, int price, String brand) {
		super(productNo, price, brand, "Color");
		this.blackInkRemaining = 100;
		this.magentaInkRemaining = 100;
		this.cyanInkRemaining = 100;
		this.yellowInkRemaining = 100;
	}
	
	private boolean checkInk() {
		return (blackInkRemaining > 0 && magentaInkRemaining > 0 && cyanInkRemaining > 0 && yellowInkRemaining > 0);
	}
	
	private void reduceInk() {
		blackInkRemaining -= 10;
		magentaInkRemaining -= 10;
		cyanInkRemaining -= 10;
		yellowInkRemaining -= 10;
	}

}
