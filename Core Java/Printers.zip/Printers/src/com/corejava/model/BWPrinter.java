package com.corejava.model;

public class BWPrinter extends Printer {
	private int blackInkRemaining;
	
	public void print() {
		if(blackInkRemaining > 0) {			
			System.out.println("Printing in Black and White");
			blackInkRemaining -= 10;
		}else {
			System.out.println("No ink left");
		}
	}
	
	public void xerox() {
		if(blackInkRemaining > 0) {			
			System.out.println("Taking Black and White Xerox");
			blackInkRemaining -= 10;
		}else {
			System.out.println("No ink left");
		}
	}
	
	public BWPrinter(int productNo, int price, String brand) {
		super(productNo, price, brand, "Black & White");
		this.blackInkRemaining = 100;
	}

}
