package com.corejava.model;

public abstract class Printer {
	private int productNo;
	private int price;
	private String brand;
	private String type;
	
	public abstract void print();
	public abstract void xerox();
	
	protected Printer(int productNo, int price, String brand, String type) {
		this.productNo = productNo;
		this.price = price;
		this.brand = brand;
		this.type = type;
	}
	
	public String displayInfo() {
		return brand+" "+type+" Printer.";
	}
	
	public void displayDetailedInfo() {
		System.out.println("Product ID: "+ productNo +" \nBrand:"+ brand +" \nPrice:"+ price +" \nType:"+ type);
	}
}
