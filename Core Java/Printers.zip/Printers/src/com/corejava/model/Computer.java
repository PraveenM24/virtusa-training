package com.corejava.model;

public class Computer {
	
	Printer pluggedPrinter;
	
	public void plugTo(Printer printer) {
		this.pluggedPrinter = printer;
		System.out.println("Computer plugged to: " + pluggedPrinter.displayInfo());
	}
	
	public void takePrintout() {
		pluggedPrinter.print();
	}
	
	public void takeXerox() {
		pluggedPrinter.xerox();
	}

}
