package com.corejava.main;

import com.corejava.model.BWPrinter;
import com.corejava.model.ColorPrinter;
import com.corejava.model.Computer;

public class PrinterMain {
	public static void main(String[] args) {
		
		BWPrinter bwPrinter1 = new BWPrinter(100, 7000, "HP");
		ColorPrinter colorPrinter1 = new ColorPrinter(101, 20000, "Samsung");
		ColorPrinter colorPrinter2 = new ColorPrinter(102, 25000, "Cannon");
		
		Computer computer = new Computer();
		
		computer.plugTo(bwPrinter1);
		computer.takePrintout();
		computer.takeXerox();
		
		computer.plugTo(colorPrinter1);
		computer.takePrintout();
		computer.takeXerox();
		
		computer.plugTo(colorPrinter2);
		computer.takePrintout();
		computer.takeXerox();
		
	}
}
