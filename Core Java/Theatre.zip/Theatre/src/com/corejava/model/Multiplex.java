package com.corejava.model;

public class Multiplex extends Theatre {
	public int ticketPrice() {
		return getBasePrice() * 2;  
	}
}
