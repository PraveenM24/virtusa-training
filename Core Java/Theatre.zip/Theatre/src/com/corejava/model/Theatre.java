package com.corejava.model;

public abstract class Theatre {
	private static final int BASE_PRICE = 100;
	
	public abstract int ticketPrice();
	
	public void watchMovie() {
		System.out.println("Screening movie...");
	}
	
	public int getBasePrice() {
		return BASE_PRICE;
	}

}
