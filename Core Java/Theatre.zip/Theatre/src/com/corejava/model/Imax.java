package com.corejava.model;

public class Imax extends Theatre{
	
	public int ticketPrice() {
		return getBasePrice() * 5;  
	}

}
