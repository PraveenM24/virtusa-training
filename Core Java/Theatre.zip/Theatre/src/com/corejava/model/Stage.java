package com.corejava.model;

public class Stage extends Theatre {

	public int ticketPrice() {
		return getBasePrice();  
	}
	
}
