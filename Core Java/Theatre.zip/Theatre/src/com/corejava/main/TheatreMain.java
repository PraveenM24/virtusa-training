package com.corejava.main;

import com.corejava.model.Theatre;
import com.corejava.model.Stage;
import com.corejava.model.Multiplex;
import com.corejava.model.Imax;

public class TheatreMain {
	public static void main(String[] args) {
		
		Theatre theatre = new Stage() ;
		System.out.println("Stage theatre: Rs."+theatre.ticketPrice());
		
		theatre = new Multiplex();
		System.out.println("Multiplex: Rs."+theatre.ticketPrice());
		
		theatre = new Imax();
		System.out.println("IMax: Rs."+theatre.ticketPrice());
		

	}
}
