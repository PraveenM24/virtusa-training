package com.corejava.main;

import java.util.List;
import java.util.Scanner;

import com.corejava.exception.InvalidInputException;
import com.corejava.model.Customer;
import com.corejava.model.Product;
import com.corejava.model.Store;
import com.corejava.serviceimpl.CustomerServiceImpl;

public class StoreMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Store store = new Store();

		store.setStoreId(1);
		store.setStoreName("Amazon");

		Customer customer1 = new Customer(1, "Praveen M");
		CustomerServiceImpl customerServices = new CustomerServiceImpl();

		int choice;

		do {
			System.out.println("\nWelcome to " + store.getStoreName() + " Store.");
			System.out.println("1. Shop Products");
			System.out.println("2. View Cart");
			System.out.println("3. Checkout");
			System.out.println("4. Watch Movie (Prime Subscription Required)");
			System.out.println("5. Upgrade to Prime");
			System.out.println("6. Exit");

			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("\nAvailable Products:");
				List<Product> products = customerServices.getProducts(store);
				customerServices.displayProducts(products);
				System.out.println("\nEnter Item No to add:\t");
				int itemNo = scanner.nextInt();
				customerServices.addProductToCart(customer1, products.get(itemNo - 1));
				break;
			case 2:
				System.out.println("\nCart:");
				List<Product> productsInCart = customerServices.getCartItems(customer1);
				float totalAmount = customer1.getCart().getTotalAmount(customer1.isPrimeCustomer());
				customerServices.displayProducts(productsInCart, totalAmount);
				break;
			case 3:
				customerServices.checkout(customer1);
				break;
			case 4:
				if (customer1.isPrimeCustomer()) {
					customerServices.watchMovie();
				} else {
					System.out.println("Feature Requires Prime Subscription!");
					System.out.println("Upgrade to Prime? (y/n)");
					String upgradeChoice = scanner.next();
					if (upgradeChoice.equalsIgnoreCase("y")) {
						customer1 = customerServices.changeMembership(customer1);
					}
				}
				break;
			case 5:
				customer1 = customerServices.changeMembership(customer1);
				System.out.println("Upgrade Successful\n");
				break;
			case 6:
				scanner.close();
				break;
			default:
				throw new InvalidInputException();
			}
		} while (choice != 6);

	}

}
