package com.corejava.service;

import java.util.List;

import com.corejava.exception.ProductNotFoundException;
import com.corejava.model.Customer;
import com.corejava.model.PrimeCustomer;
import com.corejava.model.Product;
import com.corejava.model.Store;

public interface CustomerService {

	List<Product> getProducts(Store store);

	List<Product> getCartItems(Customer customer);

	boolean addProductToCart(Customer customer, Product product) throws ProductNotFoundException;

	boolean checkout(Customer customer);

	PrimeCustomer changeMembership(Customer customer);

	void displayProducts(List<Product> products);

	void displayProducts(List<Product> products, float totalAmount);

	void watchMovie();

}
