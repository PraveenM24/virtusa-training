package com.corejava.model;

public class Product {
	private int productId;
	private String productName;
	private float price;
	private float deliveryFee;

	public Product(int productId, String productName, float price, float deliveryFee) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.deliveryFee = deliveryFee;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getDeliveryFee() {
		return deliveryFee;
	}

	public void setDeliveryFee(float deliveryFee) {
		this.deliveryFee = deliveryFee;
	}

}
