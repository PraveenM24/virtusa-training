package com.corejava.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
	private List<Product> itemsInCart = new ArrayList<>();

	public List<Product> getItemsInCart() {
		return itemsInCart;
	}

	public float getTotalAmount(boolean isPrimeCustomer) {
		float totalAmount = 0;
		if (isPrimeCustomer) {
			totalAmount =(float) itemsInCart.stream().mapToDouble(Product::getPrice).sum();
		} else {
			totalAmount =(float) itemsInCart.stream().mapToDouble(p -> p.getPrice() + p.getDeliveryFee()).sum();
		}
		return totalAmount;
	}

	public boolean addItem(Product product) {
		return itemsInCart.add(product);
	}

}
