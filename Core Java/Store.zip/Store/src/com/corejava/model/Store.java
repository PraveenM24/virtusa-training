package com.corejava.model;

import java.util.ArrayList;
import java.util.List;

public class Store {
	private int storeId;
	private String storeName;
	private List<Product> products = new ArrayList<>();

	public Store(int storeId, String storeName, List<Product> products) {
		super();
		this.storeId = storeId;
		this.storeName = storeName;
		this.products = products;
	}

	public Store() {
		products.add(new Product(100, "Smartphone", 15000.00F, 100.00F));
		products.add(new Product(101, "Headphone", 3000.00F, 50.00F));
		products.add(new Product(102, "Smartwatch", 10000.00F, 200.00F));
		products.add(new Product(103, "Bluetooth Speaker", 4000.00F, 80.00F));
		products.add(new Product(104, "TV", 40000.00F, 500.00F));
		products.add(new Product(105, "Washing Machine", 10000.00F, 100.00F));
		products.add(new Product(106, "Fridge", 20000.00F, 200.00F));
		products.add(new Product(107, "AC", 25000.00F, 200.00F));
		products.add(new Product(108, "Mixer", 8000.00F, 100.00F));
		products.add(new Product(109, "Microwave Oven", 20000.00F, 150.00F));
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

}
