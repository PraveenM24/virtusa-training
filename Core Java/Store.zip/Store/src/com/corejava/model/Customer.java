package com.corejava.model;

public class Customer {
	private int customerId;
	private String customerName;
	private Cart cart;
	private boolean isPrimeCustomer;

	public Customer(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.cart = new Cart();
		this.isPrimeCustomer = false;
	}

	public Customer(int customerId, String customerName, Cart cart, boolean isPrimeCustomer) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.cart = cart;
		this.isPrimeCustomer = isPrimeCustomer;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public boolean isPrimeCustomer() {
		return isPrimeCustomer;
	}

	public void setPrimeCustomer(boolean isPrimeCustomer) {
		this.isPrimeCustomer = isPrimeCustomer;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", cart=" + cart
				+ ", isPrimeCustomer=" + isPrimeCustomer + "]";
	}

}
