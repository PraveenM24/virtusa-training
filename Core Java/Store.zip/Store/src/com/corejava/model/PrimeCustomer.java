package com.corejava.model;

public class PrimeCustomer extends Customer {
	private String primeId;
	private int subscriptionYear;

	public PrimeCustomer(int customerId, String customerName, Cart cart, String primeId, int subscriptionYear) {
		super(customerId, customerName, cart, true);
		this.primeId = primeId;
		this.subscriptionYear = subscriptionYear;
	}

	public PrimeCustomer(Customer customer, String primeId, int subscriptionYear) {
		super(customer.getCustomerId(), customer.getCustomerName(), customer.getCart(), true);
		this.primeId = primeId;
		this.subscriptionYear = subscriptionYear;
	}

	public String getPrimeId() {
		return primeId;
	}

	public void setPrimeId(String primeId) {
		this.primeId = primeId;
	}

	public int getSubscriptionYear() {
		return subscriptionYear;
	}

	public void setSubscriptionYear(int subscriptionYear) {
		this.subscriptionYear = subscriptionYear;
	}

}
