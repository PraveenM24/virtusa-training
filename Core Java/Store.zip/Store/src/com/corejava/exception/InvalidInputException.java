package com.corejava.exception;

public class InvalidInputException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidInputException() {
		System.err.print("Exception in thread \"" + Thread.currentThread().getName() + "\" ");
		super.printStackTrace();
		System.exit(0);
	}
}
