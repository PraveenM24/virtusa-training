package com.corejava.serviceimpl;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import com.corejava.exception.ProductNotFoundException;
import com.corejava.model.Customer;
import com.corejava.model.PrimeCustomer;
import com.corejava.model.Product;
import com.corejava.model.Store;
import com.corejava.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

	@Override
	public List<Product> getProducts(Store store) {
		return store.getProducts();
	}

	@Override
	public List<Product> getCartItems(Customer customer) {
		return customer.getCart().getItemsInCart();
	}

	@Override
	public boolean addProductToCart(Customer customer, Product product) {
		boolean res = customer.getCart().addItem(product);
		if (!res) {
			throw new ProductNotFoundException();
		}
		return res;
	}

	@Override
	public boolean checkout(Customer customer) {
		float amount = customer.getCart().getTotalAmount(customer.isPrimeCustomer());
		System.out.println("Total Amount: " + amount);
		return false;
	}

	@Override
	public PrimeCustomer changeMembership(Customer customer) {
		return new PrimeCustomer(customer, UUID.randomUUID().toString(), LocalDate.now().getYear());
	}

	@Override
	public void displayProducts(List<Product> products) {
		System.out.printf("%8s %20s %10s%n", "Item No.", "Name", "Price");
		for (Product product : products) {
			System.out.printf("%8s %20s %10s%n", products.indexOf(product) + 1, product.getProductName(),
					product.getPrice());
		}
	}

	@Override
	public void displayProducts(List<Product> products, float totalAmount) {
		displayProducts(products);
		System.out.println("-------------------------------------------");
		System.out.printf("%13s %15s %10s%n", "Total Amount:", " ", totalAmount);
		System.out.println("-------------------------------------------");

	}

	@Override
	public void watchMovie() {
		System.out.println("Watching movie...");
	}

}
