package com.corejava.model;

public class Bulb {
	
	private boolean isBulbOn = false;
	
	public void clickSwitch() {
		this.isBulbOn = !isBulbOn;
	}
	
	public void showBulbStatus() {
		System.out.println("Bulb is "+ ((isBulbOn) ? "on." : "off."));
	}

}
