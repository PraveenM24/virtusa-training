package com.corejava.main;

import com.corejava.model.Bulb;

public class BulbMain {

	public static void main(String[] args) {
		
		Bulb bulb = new Bulb();
		
		bulb.showBulbStatus();
		
		bulb.clickSwitch();
		
		bulb.showBulbStatus();
		
		bulb.clickSwitch();
		
		bulb.showBulbStatus();

	}

}
