package com.corejava.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.corejava.exception.InvalidInputException;
import com.corejava.model.Customer;
import com.corejava.model.Hotel;
import com.corejava.model.Meal;
import com.corejava.service.CustomerServiceImpl;

public class HotelMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Hotel hotel = new Hotel();

		Customer customer = new Customer(100, "Praveen M");
		CustomerServiceImpl customerServices = new CustomerServiceImpl();

		hotel.addMeal(new Meal(1, "Biryani", 100));
		hotel.addMeal(new Meal(2, "Chapati", 30));
		hotel.addMeal(new Meal(3, "Fried Rice", 150));
		hotel.addMeal(new Meal(4, "Dosa", 40));

		int choice;
		try {

			do {

				System.out.println("Options");
				System.out.println("1. View Cart Items");
				System.out.println("2. Add Items to Cart");
				System.out.println("3. Remove Items from Cart");
				System.out.println("4. Empty Cart");
				System.out.println("5. Checkout");
				System.out.println("6. Exit");
				choice = scanner.nextInt();

				switch (choice) {
				case 1:
					customerServices.viewCart(customer, hotel);
					break;
				case 2:
					System.out.println("Menu");
					hotel.getMeals().stream().forEach(meal -> System.out.println(
							hotel.getMeals().indexOf(meal) + 1 + ". " + meal.getName() + " \t\tRs." + meal.getPrice()));
					System.out.println("\nEnter your choice:\t");
					int itemNo = (scanner.nextInt()) - 1;
					System.out.println("\nEnter quantity:\t");
					int quantity = scanner.nextInt();
					if (customerServices.addMeal(customer, quantity, hotel.getMeals().get(itemNo))) {
						System.out.println("Meal added to cart");
					}
					break;
				case 3:
					customerServices.viewCart(customer, hotel);
					System.out.println("Enter Item No to be removed:\t");
					itemNo = scanner.nextInt();
					if (customerServices.removeMeal(customer, itemNo)) {
						System.out.println("Meal removed from cart");
					}
					break;
				case 4:
					if (customerServices.clearCart(customer)) {
						System.out.println("Cart Cleared");
					}
					break;
				case 5:
					customerServices.checkout(customer, hotel);
					break;
				case 6:
					scanner.close();
					System.out.println("Thankyou!");
					break;
				default:
					throw new InvalidInputException();
				}
			} while (choice != 6);
		} catch (InputMismatchException | IndexOutOfBoundsException e) {
			throw new InvalidInputException();
		}
	}

}
