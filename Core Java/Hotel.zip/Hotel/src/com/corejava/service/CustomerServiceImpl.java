package com.corejava.service;

import com.corejava.exception.InvalidInputException;
import com.corejava.exception.MealNotFoundException;
import com.corejava.model.Customer;
import com.corejava.model.Hotel;
import com.corejava.model.Meal;

public class CustomerServiceImpl implements CustomerService {

	@Override
	public boolean addMeal(Customer customer, int quantity, Meal meal) {
		if(quantity <= 0) {
			throw new InvalidInputException();
		}
		return customer.getCart().addItem(quantity, meal);
	}

	@Override
	public boolean removeMeal(Customer customer, int itemNo) {
		if(customer.getCart().getMealsInCart().size() < itemNo || itemNo<0) {
			throw new MealNotFoundException();
		}
		customer.getCart().removeItem(itemNo);
		return false;
	}

	@Override
	public boolean clearCart(Customer customer) {
		return customer.getCart().clearCart();
	}

	@Override
	public void viewCart(Customer customer, Hotel hotel) {
		customer.getCart().displayCartItems(hotel);		
	}

	@Override
	public boolean checkout(Customer customer, Hotel hotel) {
		clearCart(customer);
		System.out.println("Total Amount: "+ customer.getCart().getTotalAmount(hotel));
		return false;
	}

}
