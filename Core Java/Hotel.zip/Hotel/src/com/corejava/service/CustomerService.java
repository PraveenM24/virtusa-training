package com.corejava.service;

import com.corejava.exception.InvalidInputException;
import com.corejava.exception.MealNotFoundException;
import com.corejava.model.Customer;
import com.corejava.model.Hotel;
import com.corejava.model.Meal;

public interface CustomerService {
	boolean addMeal(Customer customer, int quantity, Meal meal) throws InvalidInputException;
	boolean removeMeal(Customer customer, int itemNo) throws MealNotFoundException;
	boolean clearCart(Customer customer);
	void viewCart(Customer customer, Hotel hotel);
	boolean checkout(Customer customer, Hotel hotel);	
}
