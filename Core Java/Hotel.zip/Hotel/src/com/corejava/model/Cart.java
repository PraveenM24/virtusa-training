package com.corejava.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Cart {
	private List<int[]> mealsInCart;

	public List<int[]> getMealsInCart() {
		return mealsInCart;
	}

	public float getTotalAmount(Hotel hotel) {
		float totalAmount = 0;
		if (!mealsInCart.isEmpty()) {
			totalAmount = (float) mealsInCart.stream().mapToDouble(meal -> hotel.getMeal(meal[0]).getPrice() * meal[1]).sum();
		}
		return totalAmount;
	}

	public void displayCartItems(Hotel hotel) {

		System.out.println("ItemNo\tItem\t\t Quantity");
		if (!Objects.isNull(mealsInCart)) {
			int itemNo = 1;

			for (int[] mealArr : mealsInCart) {
				System.out.println(itemNo++ + ".\t" + hotel.getMeal(mealArr[0]).getName() + "\t\t " + mealArr[1]);
			}
			System.out.println("-------------------------------------");
			System.out.println("Total:\t\t Rs." + getTotalAmount(hotel));
			System.out.println("-------------------------------------\n");
		} else {
			System.out.println("Empty\n");
		}
	}
	
	private boolean itemExistsInCart(int quantity, Meal meal) {
		for(int[] mealArr : mealsInCart) {
			if(mealArr[0] == meal.getId()) {
				mealArr[1] += quantity;
				return true;
			}
		}
		return false;
	}

	public boolean addItem(int quantity, Meal meal) {
		if(Objects.isNull(mealsInCart)) {
			mealsInCart = new ArrayList<>();
		}
		if(!itemExistsInCart(quantity, meal)) {
			mealsInCart.add(new int[] { meal.getId(), quantity });
		}
		return true;
	}

	public boolean removeItem(Meal meal) {
		for (int[] mealArr : mealsInCart) {
			if (mealArr[0] == meal.getId()) {
				mealsInCart.remove(mealArr);
				break;
			}
		}
		return true;
	}

	public boolean removeItem(int itemNo) {
		for (int[] mealArr : mealsInCart) {
			if (mealsInCart.indexOf(mealArr) == itemNo - 1) {
				mealsInCart.remove(mealArr);
				break;
			}
		}
		return true;
	}

	public boolean clearCart() {
		mealsInCart.clear();
		return true;
	}
}
