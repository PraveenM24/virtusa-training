package com.corejava.model;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
	private String name;
	private long phone;
	private List<Meal> meals;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public List<Meal> getMeals() {
		return meals;
	}

	public Meal getMeal(int id) {
		for (Meal m : meals) {
			if (m.getId() == id) {
				return m;
			}
		}
		return new Meal();
	}

	public void addMeals(List<Meal> meals) {
		this.meals = meals;
	}

	public void addMeal(Meal meal) {
		try {
			meals.add(meal);
		} catch (NullPointerException e) {
			meals = new ArrayList<>();
			addMeal(meal);
		}
	}

}
