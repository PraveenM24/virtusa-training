package com.corejava.exception;

public class MealNotFoundException extends RuntimeException {
	public MealNotFoundException() {
		System.err.print("Exception in thread \"" + Thread.currentThread().getName() + "\" ");
		super.printStackTrace();
		System.exit(0);
	}
}
