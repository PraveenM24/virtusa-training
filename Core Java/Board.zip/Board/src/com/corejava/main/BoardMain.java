package com.corejava.main;

import com.corejava.model.Pen;
import com.corejava.model.Board;

public final class BoardMain {
	public static void main(String[] args) {
		final Pen pen1 = new Pen();
		final Board board = new Board();
		
		pen1.write(board, "Writing sentence on the board.");
		pen1.write(board, "Sentences will get added to the board as we write.");
		pen1.write(board, "Calling clearBoard() will remove all the contents");
		board.clearBoard();
		
		
	}
}
