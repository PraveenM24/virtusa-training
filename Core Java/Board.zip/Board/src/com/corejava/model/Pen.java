package com.corejava.model;

public class Pen {
	
	private int inkCapacity = 200;
	
	/* Adds contents by calling the board object */
	public void write(Board board, String content) {
		if(inkCapacity > 0) {			
			board.addContents(content, content.length());
			inkCapacity -= content.length();
		}else {
			System.err.println("Pen has no ink.");	
		}
	}	

}
