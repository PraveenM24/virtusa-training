package com.corejava.model;

public class Board {
	
	private String contents = "";
	private int capacity = 500;
	private int capacityFilled;
	
	/* Concatenates contents from pen to board */
	public void addContents(String content, int contentLength) {
		if(capacityFilled == capacity) {
			System.err.println("Board is completely full!");
		}else if(contentLength > capacity) {
			System.err.println("Content does not fit in the board!");
		}else {
			contents += " " + content;
			capacityFilled = contents.length();
			System.out.println("Board Contents:\n"+contents);
		}
	}
	
	/* Removes all the contents */
	public void clearBoard() {
		contents = "";
		capacityFilled = 0;
		System.out.println("Board is cleared!");
	}
	
}
