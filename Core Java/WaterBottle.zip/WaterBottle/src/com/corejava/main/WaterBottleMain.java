package com.corejava.main;

import com.corejava.model.WaterBottle;
import java.util.Scanner;

public class WaterBottleMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		WaterBottle waterBottle = new WaterBottle();
		
		System.out.print("Enter the bottle capacity (in ml):\t");
		waterBottle.setCapacity(scanner.nextInt());
		
		int choice;
		
		do{
			System.out.println("Enter your choice:");
			System.out.println(" [ 1 ] Fill Water\n [ 2 ] Drink Water\n [ 3 ] Empty the bottle\n [ 4 ] Exit\n");
			choice = scanner.nextInt();
			
			switch(choice) {
				case 1:
					System.out.print("Enter amount of water to be filled:\t");
					int amountOfWater = scanner.nextInt();
					waterBottle.fillWater(amountOfWater);
					break;
				case 2:
					waterBottle.sipWater();
					break;
				case 3:
					waterBottle.emptyBottle();
					break;
				case 4:
					scanner.close();
					break;
				default:
					System.out.println("Invalid option");
			}
		}while(choice != 4);
		
	}
}
