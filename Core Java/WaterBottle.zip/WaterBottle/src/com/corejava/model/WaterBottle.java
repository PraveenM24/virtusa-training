package com.corejava.model;

public class WaterBottle {
	private int capacity;
	private int capacityFilled;
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public void fillWater(int amountOfWater) {
		if(capacityFilled == capacity) {
			System.out.println("Bottle is full! "+amountOfWater+"ml of water has overflown");
		}else if(amountOfWater > (capacity-capacityFilled)) {
			System.out.println("Bottle is full! "+(amountOfWater-(capacity-capacityFilled))+"ml of water has overflown");
		}else {
			capacityFilled += amountOfWater;
			System.out.println("Bottle has "+capacityFilled+"ml of water");
		}
	}
	
	public void sipWater() {
		if(capacityFilled <= 10) {
			System.out.println("Bottle is empty!!");
		}else {
			if(capacityFilled < 10) {				
				capacityFilled -= 10;
			}else {
				capacityFilled = 0;
			}
			System.out.println("Bottle has "+capacityFilled+"ml of water remaining.");
		}
	}
	
	public void emptyBottle() {
		capacityFilled = 0;
		System.out.println("Bottle has been emptied!");
	}

}
