package com.corejava.model;

public class Car {
	private int speed = 40;
	
	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public void accelerate(int s) {
		if(checkSpeedInput(s)) {
			speed += s;
			if (speed > 200)
				speed = 200;
			System.out.println("Car is going at "+speed+" km/hr");
		}else {			
			System.out.println("Invalid speed");
		}	
	}
	
	public void decelerate(int s) {
		if (speed <= 0) {
			System.out.println("Car has stopped.");
		}else {	
			speed -= s;
			if (speed < 0)
				speed = 0;
			System.out.println("Car is going at "+speed+" km/hr");
		}
	}
	
	private boolean checkSpeedInput(int speed) {
		return (speed>0 || speed<=200);
	}
	
}
