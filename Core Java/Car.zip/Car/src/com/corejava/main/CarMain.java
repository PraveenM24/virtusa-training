package com.corejava.main;

import com.corejava.model.Car;

public class CarMain {
	public static void main(String[] args) {
		Car car = new Car();
		
		car.accelerate(50);
		car.decelerate(60);
	}
}
