package com.corejava.model;

public class Name {
	private String firstName;
	private String middleName;
	private String lastName;
	
	public Name(String fname, String mname, String lname) {
		this.firstName = fname;
		this.middleName = mname;
		this.lastName = lname;
	}
	
	public String getFullName() {
		return firstName+" "+middleName+" "+lastName;
	}
}
