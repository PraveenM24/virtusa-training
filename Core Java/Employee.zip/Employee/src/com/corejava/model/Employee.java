package com.corejava.model;

public class Employee {
	private int employeeId;
	private Name employeeName;
	private String email;
	private String joiningDate;
	private String address;
	private long phone;
	
	public Employee(int eid, Name ename, String email, String jdate, String address, long phone) {
		this.employeeId = eid;
		this.employeeName = ename;
		this.email = email;
		this.joiningDate = jdate;
		this.address = address;
		this.phone = phone;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public Name getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(Name employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public void displayEmployeeDetails() {
		System.out.println(" Employee ID: "+ employeeId +
							"\n Name: "+ employeeName.getFullName() +
							"\n Email: "+ email +
							"\n Joining Date: "+ joiningDate +
							"\n Address: "+ address +
							"\n Phone: "+ phone +"\n");
	}

}
