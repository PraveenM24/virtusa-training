package com.corejava.main;

import com.corejava.model.Employee;
import com.corejava.model.Name;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee(1001, new Name("Employee", "", "1"), "emp1@mail.com", "01-AUG-2022", "Addr1", 8524082460L);
		Employee employee2 = new Employee(1002, new Name("Employee", "", "2"), "emp2@mail.com", "20-MAR-2022", "Addr2", 9624067894L);
		
		employee1.displayEmployeeDetails();
		employee2.displayEmployeeDetails();
		
		Employee employee3 = employee2;
		
		employee3.displayEmployeeDetails();
		
		employee3.setEmployeeId(1003);
		
		employee2.displayEmployeeDetails();
		employee3.displayEmployeeDetails();
		
	}
}
