package com.corejava.model;

public class Filter {
	
	static final String SUCCESS_MSG = "Employee Found !...";
	
	//Find Department Name and Employees
	public void searchDepartment(Department[] departments, int id) {
		for(Department dep : departments) {
			if(dep.getID() == id) {
				System.out.println("Department Name: "+dep.getName());
				System.out.println("All Employees:-");
				for(Employee emp: dep.getEmployees()) {
					emp.displayEmployee();
				}
			}
		}
	}
	
	//Find Department of Employee
	public void searchDepartment(Department[] departments, Employee employee) {
		for(Department dep : departments) {
			for(Employee emp : dep.getEmployees()) {
				if(emp.getEmpID() == employee.getEmpID()) {
					System.out.println("Employee "+employee.getName()+" belongs to "+dep.getName());
				}
			}
		}
	}
	
	//Find Employee using Employee ID
	public void searchEmployee(Employee[] employees, int id) {
		for(Employee emp : employees) {
			if(emp.getEmpID() == id) {
				System.out.println(SUCCESS_MSG);
				emp.displayEmployee();
			}
		}
	}
	
	//Find Employee using Employee Name
	public void searchEmployee(Employee[] employees, String name) {
		for(Employee emp : employees) {
			if(emp.getName().equalsIgnoreCase(name)) {
				System.out.println(SUCCESS_MSG);
				emp.displayEmployee();
				break;
			}
		}
	}
	
	
	//Find Employee using Employee Phone
	public void searchEmployee(Employee[] employees, long phone) {
		for(Employee emp : employees) {
			if(emp.getPhone() == phone) {
				System.out.println(SUCCESS_MSG);
				emp.displayEmployee();
			}
		}
	}
	
	//Find Employee using Employee Salary
	public void searchEmployee(Employee[] employees, float salary) {
		for(Employee emp : employees) {
			if(Float.compare(emp.getSalary(), salary)  == 0) {
				System.out.println(SUCCESS_MSG);
				emp.displayEmployee();
			}
		}
	}
}
