package com.corejava.model;

public class Department {
	private int id;
	private String name;
	private String location;
	private Employee[] employees;
	
	public Department(int id, String name, String location, Employee[] employees) {
		this.id = id;
		this.name = name;
		this.location = location;
		this.employees = employees;
	}
	
	public int getID() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getLocation() {
		return location;
	}

	public Employee[] getEmployees() {
		return employees;
	}

}
