package com.corejava.model;

public class Employee {
	private int empID;
	private String name;
	private long phone;
	private float salary;
	
	public Employee(int eid, String ename, long phn, float salary) {
		this.empID = eid;
		this.name = ename;
		this.phone = phn;
		this.salary = salary;
	}

	public int getEmpID() {
		return empID;
	}

	public String getName() {
		return name;
	}

	public long getPhone() {
		return phone;
	}

	public float getSalary() {
		return salary;
	}
	
	public void displayEmployee() {
		System.out.println("+-------------------------------------------------------------------------------+");
		System.out.println("| ID: "+empID+"\tName: "+name+"\t\tPhone: "+phone+"\tSalary: "+salary+"\t|");
		System.out.println("+-------------------------------------------------------------------------------+");
	}

}
