package com.corejava.main;

import com.corejava.model.Employee;
import com.corejava.model.Department;
import com.corejava.model.Filter;

public class Main {
	public static void main(String[] args) {
		Employee[] employees1 = {new Employee(100, "Employee1", 8524082460l, 10000.00f),
									new Employee(101, "Employee2", 9486189140l, 12000.00f),
									new Employee(102, "Employee3", 63882812430l, 8000.00f),
									new Employee(103, "Employee4", 9442792500l, 15000.00f),
									new Employee(104, "Employee5", 6540606785l, 9000.00f) };
		
    	Employee[] employees2 = {new Employee(105, "Employee6", 9443090044l, 10000.00f),
									new Employee(106, "Employee7", 6357492570l, 15000.00f),
									new Employee(107, "Employee8", 9348501626l, 20000.00f),
									new Employee(108, "Employee9", 6724985115l, 25000.00f),
									new Employee(109, "Employee10", 8246951720l, 18000.00f) };
		
		Department department1 = new Department(10, "Department1", "Loc1", employees1);
		Department department2 = new Department(15, "Department2", "Loc2", employees2);
		
		Department[] departments = {department1, department2};
		
		Filter filter = new Filter();
	
		filter.searchDepartment(departments, 10);
		filter.searchDepartment(departments, new Employee(100, "Employee1", 8524082460l, 10000.00f));
		
		filter.searchEmployee(employees1, 100);
		filter.searchEmployee(employees1, "Employee2");
		filter.searchEmployee(employees1, 63882812430l);
		filter.searchEmployee(employees1, 10000.00f);
		
		filter.searchEmployee(employees1, 200);
		
		
	}
}
