package com.corejava.main;

import com.corejava.model.Car;

public class DriverMain {
	public static void main(String[] args) {
		Car car1 = new Car();
		car1.drive();
		car1.start();
		car1.drive();
		car1.stop();
		car1.stop();
	}
}
