package com.corejava.model;

public class Car {
	private boolean isStarted = false;
	private boolean isDriving = false;
	
	public void start() {
	    if(!isStarted && !isDriving) {
	            isStarted = true;
	    }
	    else {
	    	System.err.println("Car already started!");  	
	    }
	}   

	public void drive() {
	    if(isStarted) {	    	
	    	isDriving = true;
	    }
	    else {	    	
	    	System.err.println("Start car to drive!");
	    }
	    showState();
	}

	public void stop()
	{
	    if(isStarted)
	    {
	        isStarted = false;
	        isDriving = false;
	    }
	    else {	    	
	    	System.err.println("Car already stopped!");
	    }
	    showState();
	}

	private void showState()
	{
	    if(isStarted && isDriving)
	        System.out.println("Driving...");
	    if(!isStarted && !isDriving)
	        System.out.println("Stopped...");
	    if(isStarted && !isDriving)
	        System.out.println("Started...");
	}
}
