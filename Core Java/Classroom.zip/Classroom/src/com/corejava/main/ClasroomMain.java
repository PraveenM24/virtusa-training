package com.corejava.main;

import com.corejava.model.Student;
import com.corejava.model.Classroom;
import java.util.List;
import java.util.ArrayList;


public class ClasroomMain {
	public static void main(String [] args) {
		Student student1 = new Student(1001, "Praveen", "05-AUG-00", "addr1");
		Student student2 = new Student(1002, "Prathik", "23-MAR-00", "addr2");
		Student student3 = new Student(1003, "Roy Richard", "16-DEC-99", "addr3");
		
		List<Student> students = new ArrayList<> ();
		
		students.add(student1);
		students.add(student2);
		students.add(student3);
		
		Classroom classroom1 = new Classroom(1, "Computer Science Class", students, 30, 5, true);
		
		classroom1.displayClassroomDetails();
		
	}
}
