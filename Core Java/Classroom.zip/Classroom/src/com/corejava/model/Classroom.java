package com.corejava.model;

import java.util.List;

public class Classroom {
	private int classroomId;
	private String name;
	private List<Student> students;
	private int noOfDesks;
	private int noOfFans;
	private boolean hasProjector;
	
	public Classroom(int id, String name, List<Student> students, int noOfDesks, int noOfFans, boolean hasProjector) {
		this.classroomId = id;
		this.name = name;
		this.students = students;
		this.noOfDesks = noOfDesks;
		this.noOfFans = noOfFans;
		this.hasProjector = hasProjector;
	}
	
	public void displayClassroomDetails() {
		System.out.println("Class ID: "+classroomId+",\nClass Name: "+name+",\nDesks: "+noOfDesks+",\nFans:"+noOfFans+",\nProjector: "+(hasProjector ? "Available" : "Not Available"));
		System.out.println("Students:");
		for(Student student : students) {
			student.getStudentDetails();
		}
	}
}
