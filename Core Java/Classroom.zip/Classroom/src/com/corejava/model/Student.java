package com.corejava.model;

public class Student {
	private int studentId;
	private String name;
	private String dateOfBirth;
	private String address;
	
	public Student(int id, String name, String dob, String addr) {
		this.studentId = id;
		this.name = name;
		this.dateOfBirth = dob;
		this.address = addr;
	}
	
	public void getStudentDetails() {
		System.out.println("+---------------------------------------------------------------------------------------+");
		System.out.println("|ID: "+studentId+" \t| Name: "+name+" \t| DOB: "+dateOfBirth+" \t| Address: "+address+"\t|");
		System.out.println("+---------------------------------------------------------------------------------------+");
	}
}
