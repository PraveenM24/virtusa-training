package com.corejava.main;

import java.time.LocalDate;

public class Product {
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", date=" + date + ", price="
				+ price + ", company=" + company + "]";
	}

	private int productId;
	private String productName;
	private LocalDate date;
	private double price;
	private String company;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Product(int productId, String productName, LocalDate localDate, double price, String company) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.date = localDate;
		this.price = price;
		this.company = company;
	}

}
