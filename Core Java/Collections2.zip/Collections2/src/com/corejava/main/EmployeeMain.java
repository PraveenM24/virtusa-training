package com.corejava.main;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class EmployeeMain {
	public static void main(String [] args) {
		Employee emp1 = new Employee(1, "Praveen M", 15000F);
		Employee emp2 = new Employee(1, "Praveen M", 15000F);
		Employee emp4 = new Employee(3, "Roy", 18000F);
		Employee emp3 = new Employee(2, "Prathik", 16000F);
		
		Set<Employee> empSet = new HashSet<>();
		empSet.add(emp1);
		empSet.add(emp2);
		empSet.add(emp3);
		
		empSet.forEach(System.out::println);
		
		Set<Employee> empSet2 = new TreeSet<>(Comparator.comparing(Employee::getEmployeeId));
		
		System.out.println();
		empSet2.add(emp1);
		empSet2.add(emp2);
		empSet2.add(emp3);
		empSet2.add(emp4);
		
		empSet2.forEach(System.out::println);
	}
}
