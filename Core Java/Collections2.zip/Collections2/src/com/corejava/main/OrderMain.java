package com.corejava.main;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class OrderMain {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<>();

		products.add(new Product(1, "Smartphone", LocalDate.parse("2022-08-12"), 50000, "Apple"));
		products.add(new Product(2, "Heaphones", LocalDate.parse("2022-09-14"), 7000, "JBL"));
		products.add(new Product(3, "TV", LocalDate.parse("2022-07-03"), 70000, "Sony"));
		products.add(new Product(4, "Speakers", LocalDate.parse("2022-06-25"), 1300, "Boat"));
		products.add(new Product(5, "Washing Machine", LocalDate.parse("2022-08-22"), 50000, "LG"));
		products.add(new Product(6, "Mixer", LocalDate.parse("2022-06-05"), 8000, "LG"));

		// 1. Create Order and Add Products
		Order order1 = new Order();
		order1.setOrderId(1);
		order1.setProducts(products.subList(0, 3));
		order1.setOrderDate(LocalDate.now());
		System.out.println(order1.getTotalPrice());

		// 2. Get All Products from order
		order1.getProducts().stream().forEach(System.out::println);
		System.out.println();

		// 3. Get Particular Product from Order
		int searchProductId = 1;
		Optional<Product> searchRes = order1.getProducts().stream().filter(p -> p.getProductId() == searchProductId)
				.findFirst();
		if (searchRes.isPresent()) {
			searchRes.get().toString();
		}
		System.out.println();

		String searchProductName = "Smartphone";
		List<Product> searchRes2 = order1.getProducts().stream()
				.filter(p -> p.getProductName().equals(searchProductName)).toList();
		searchRes2.forEach(System.out::println);
		System.out.println();

		// 4. Get Product with max/min price;
		Optional<Product> maxProduct = order1.getProducts().stream().max(Comparator.comparing(Product::getPrice));
		if (maxProduct.isPresent()) {
			System.out.println(maxProduct.get().toString());
		}

		Optional<Product> minProduct = order1.getProducts().stream().min(Comparator.comparing(Product::getPrice));
		if (minProduct.isPresent()) {
			System.out.println(minProduct.get().toString());
		}
		System.out.println();

		// 5. Find total price
		Double totalAmount = order1.getProducts().stream().mapToDouble(Product::getPrice).sum();
		System.out.println(totalAmount);
		System.out.println();

		// 6. Convert list to set
		Product p1 = new Product(1, "Smartphone", LocalDate.parse("2022-08-12"), 50000, "Apple");
		Product p2 = new Product(2, "Heaphones", LocalDate.parse("2022-09-14"), 7000, "JBL");

		List<Product> products1 = new ArrayList<>();
		products1.add(p1);
		products1.add(p1);
		products1.add(p1);
		products1.add(p2);
		products1.add(p2);
		Set<Product> testSet = products1.stream().collect(Collectors.toSet());
		testSet.forEach(System.out::println);

	}

}
