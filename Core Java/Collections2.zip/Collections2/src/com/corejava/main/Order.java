package com.corejava.main;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Order {
	private long orderId;
	private LocalDate orderDate;
	private List<Product> products = new ArrayList<>();
	private double totalPrice;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public void addProduct(Product product) {
		products.add(product);
	}

	public double getTotalPrice() {
		totalPrice = 0;
		products.forEach(p -> totalPrice += p.getPrice());
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Order(long orderId, LocalDate orderDate, List<Product> products) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.products = products;
	}
	
	public Order() {
		
	}

}
