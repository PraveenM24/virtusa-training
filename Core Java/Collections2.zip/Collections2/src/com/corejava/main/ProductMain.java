package com.corejava.main;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ProductMain {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<>();

		// 1. Add the product to Collection
		products.add(new Product(1, "Smartphone", LocalDate.parse("2022-08-12"), 50000, "Apple"));
		products.add(new Product(2, "Heaphones", LocalDate.parse("2022-09-14"), 7000, "JBL"));
		products.add(new Product(3, "TV", LocalDate.parse("2022-07-03"), 70000, "Sony"));
		products.add(new Product(4, "Speakers", LocalDate.parse("2022-06-25"), 1300, "Boat"));
		products.add(new Product(5, "Washing Machine", LocalDate.parse("2022-08-22"), 50000, "LG"));
		products.add(new Product(6, "Mixer", LocalDate.parse("2022-06-05"), 8000, "LG"));

		// 2. Display all products.
		products.stream().forEach(p -> System.out.println(p.toString()));
		System.out.println();

		// 3. Get a product by Id
		int checkId = 1;
		Optional<Product> searchCheckId = products.stream().filter(p -> p.getProductId() == checkId).findFirst();
		if (searchCheckId.isPresent()) {
			System.out.println(searchCheckId.get().toString());
		}
		System.out.println();

		// 4. Get the product between 1000 - 1500 price
		products.stream().filter(p -> p.getPrice() < 1500 && p.getPrice() > 1000)
				.forEach(p -> System.out.println(p.toString()));
		System.out.println();

		// 5. Get the product belongs to same company in another list
		String checkName = "LG";
		List<Product> searchResultName = products.stream().filter(p -> (p.getCompany().equals(checkName))).toList();
		searchResultName.stream().forEach(p -> System.out.println(p.toString()));
		System.out.println();

		// 6. Get the products by date
		LocalDate checkDate = LocalDate.parse("2022-07-03");
		List<Product> searchResultDate = products.stream().filter(p -> p.getDate().compareTo(checkDate) == 0).toList();
		searchResultDate.stream().forEach(p -> System.out.println(p.toString()));
		System.out.println();

		// 7. Get the product by name
		String checkPName = "Smartphone";
		List<Product> searchResultPName = products.stream().filter(p -> p.getProductName().equals(checkPName)).toList();
		searchResultPName.stream().forEach(p -> System.out.println(p.toString()));
		System.out.println();

		// 8. Count number of product
		long count = products.stream().count();
		System.out.println(count);
		System.out.println();

		// 9. find max and min product price.
		Optional<Product> maxProduct = products.stream().max(Comparator.comparing(Product::getPrice));
		Optional<Product> minProduct = products.stream().min(Comparator.comparing(Product::getPrice));
		double maxProductPrice = 0;
		double minProductPrice = 0;
		if (maxProduct.isPresent()) {
			maxProductPrice = maxProduct.get().getPrice();
		}
		if (minProduct.isPresent()) {
			minProductPrice = minProduct.get().getPrice();
		}
		System.out.println(maxProductPrice);
		System.out.println(minProductPrice);

	}

}
